package com.hbxm.fuckmc;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;
import java.io.File;

public class HookInit implements IXposedHookLoadPackage {
    
    private static final int DELAY = 500;
    private static final int MAX_RETRY = 3;
    private final Handler handler = new Handler(Looper.getMainLooper());
    
    @Override
    public void handleLoadPackage(LoadPackageParam param) throws Throwable {
        if (!param.packageName.equals("com.mojang.minecraftpe")) {
            return;
        }
        
        XposedHelpers.findAndHookMethod(
            "com.mojang.minecraftpe.MainActivity",
            param.classLoader,
            "onCreate",
            Bundle.class,
            new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    final Activity activity = (Activity) param.thisObject;
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            deleteWithRetry(activity,0);
                        }
                    }, DELAY);
                }
            }
        );
    }
    private void deleteWithRetry(final Activity activity, final int retry) {
        final File targetDir = new File(activity.getDataDir(), "shared_prefs");
        boolean success = false;
        if (targetDir.exists()) {
            success = deleteDir(targetDir);
        } else {
            success = true;
        }
        final boolean result = success;
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                String msg = "删除" + (result ? "成功" : "失败");
                msg += " 重试:" + (retry + 1);
                msg += "\n" + targetDir.getAbsolutePath();
                Toast.makeText(activity,msg,Toast.LENGTH_LONG).show();
            }
        });
        if (result) {
            closeApp(activity);
        } else if (retry < MAX_RETRY - 1) {
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    deleteWithRetry(activity, retry + 1);
                }
            }, DELAY * (retry + 1));
        } else {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(activity, "次数过多",Toast.LENGTH_LONG).show();
                }
            });
        }
    }
    private boolean deleteDir(File dir) {
        if (dir.isDirectory()) {
            File[] files = dir.listFiles();
            if (files != null) {
                for (File file : files) {
                    deleteDir(file);
                }
            }
        }
        return dir.delete();
    }
    private void closeApp(Activity activity) {
        try {
            activity.finish();
        } catch (Exception e) {}
    }
}
